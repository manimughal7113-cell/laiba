// Ye page hidden (offscreen) chalta hai. Iska kaam sirf ye hai:
// background.js se ek PDF URL milta hai, ye usay fetch karta hai,
// pdf.js se uska text nikalta hai, aur emails dhoond kar wapas bhej deta hai.

pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('pdf.worker.min.js');

const EMAIL_REGEX = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;

async function extractTextAndEmails(pdfUrl) {
  const response = await fetch(pdfUrl);
  if (!response.ok) {
    throw new Error(`PDF download fail (status ${response.status})`);
  }
  const arrayBuffer = await response.arrayBuffer();

  const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
  const pdf = await loadingTask.promise;

  let fullText = '';
  const maxPages = Math.min(pdf.numPages, 30); // safety cap taake bohot badi files hang na karein

  for (let i = 1; i <= maxPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    const pageText = content.items.map(item => item.str).join(' ');
    fullText += pageText + '\n';
  }

  const trimmedLength = fullText.replace(/\s/g, '').length;
  const isImageBased = trimmedLength < 30; // itna kam text = likely scanned/image PDF

  const matches = fullText.match(EMAIL_REGEX) || [];
  const junkPatterns = [
    /\.(png|jpg|jpeg|gif|svg|webp|css|js)$/i,
    /example\.com$/i,
    /sentry\.io$/i
  ];
  const emails = [...new Set(matches)].filter(e => !junkPatterns.some(p => p.test(e)));

  return { emails, isImageBased, textLength: trimmedLength };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target !== 'offscreen' || msg.action !== 'processPdf') {
    return false;
  }

  extractTextAndEmails(msg.url)
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((err) => sendResponse({ ok: false, error: err.message }));

  return true; // async response
});
