document.getElementById('brandLabel').textContent = BRAND_NAME;
document.getElementById('mainTitle').textContent = BRAND_NAME + ' - Email Suite';

// ============================================================
// TAB SWITCHING
// ============================================================
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('panel-' + btn.dataset.tab).classList.add('active');
  });
});

// ============================================================
// LICENSE GATE
// ============================================================
const licenseGate = document.getElementById('licenseGate');
const licenseKeyInput = document.getElementById('licenseKeyInput');
const licenseMsg = document.getElementById('licenseMsg');

async function checkLicenseAndGate() {
  const data = await chrome.storage.local.get(['licenseKey', 'licensed']);
  if (!data.licenseKey) {
    licenseGate.style.display = 'flex';
    return;
  }
  // background har 10 min mein khud check karta hai; yahan turant bhi
  // ek fresh check karwa lete hain jab popup khule.
  chrome.runtime.sendMessage({ action: 'CHECK_LICENSE' });
  setTimeout(async () => {
    const fresh = await chrome.storage.local.get(['licensed']);
    licenseGate.style.display = fresh.licensed ? 'none' : 'flex';
    if (!fresh.licensed) {
      licenseMsg.textContent = 'License invalid ya revoked hai. Admin se naya key lein.';
    }
  }, 700);
}

document.getElementById('activateBtn').addEventListener('click', async () => {
  const key = licenseKeyInput.value.trim();
  if (!key) return;
  licenseMsg.textContent = 'Check kar raha hoon...';
  try {
    const res = await fetch(`${LICENSE_SERVER_URL}/api/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key })
    });
    const json = await res.json();
    if (json.valid) {
      await chrome.storage.local.set({ licenseKey: key, licensed: true });
      licenseGate.style.display = 'none';
    } else {
      licenseMsg.textContent = 'Ye key valid nahi hai ya revoke ho chuki hai.';
    }
  } catch (e) {
    licenseMsg.textContent = 'Server se connect nahi ho pa raha. LICENSE_SERVER_URL check karein (config.js).';
  }
});

// ============================================================
// DASHBOARD
// ============================================================
function refreshDashboard() {
  chrome.storage.local.get(['obo_emails', 'pdf_emails', 'obo_status', 'pdf_status'], (data) => {
    const oboCount = (data.obo_emails || []).length;
    const pdfCount = (data.pdf_emails || []).length;
    document.getElementById('dashOboCount').textContent = oboCount;
    document.getElementById('dashPdfCount').textContent = pdfCount;
    document.getElementById('dashTotalCount').textContent = oboCount + pdfCount;
    document.getElementById('dashOboStatus').textContent = data.obo_status || 'idle';
    document.getElementById('dashPdfStatus').textContent = data.pdf_status || 'idle';
  });
}

document.getElementById('clearAllBtn').addEventListener('click', () => {
  if (!confirm('Sara collected data (One-by-One + PDF) permanently delete ho jayega. Confirm karein?')) return;
  chrome.storage.local.remove([
    'obo_emails', 'obo_log', 'obo_status', 'obo_resumeProgress', 'obo_savedKeywords',
    'pdf_emails', 'pdf_log', 'pdf_status'
  ], () => {
    refreshDashboard();
    refreshOboUI();
    refreshPdfUI();
  });
});

// ============================================================
// ONE-BY-ONE TAB
// ============================================================
const oboTradesEl = document.getElementById('oboTrades');
const oboCitiesEl = document.getElementById('oboCities');

function restoreOboInputs() {
  chrome.storage.local.get(['obo_tradesText', 'obo_citiesText'], (data) => {
    if (typeof data.obo_tradesText === 'string') oboTradesEl.value = data.obo_tradesText;
    if (typeof data.obo_citiesText === 'string') oboCitiesEl.value = data.obo_citiesText;
  });
}
oboTradesEl.addEventListener('input', () => chrome.storage.local.set({ obo_tradesText: oboTradesEl.value }));
oboCitiesEl.addEventListener('input', () => chrome.storage.local.set({ obo_citiesText: oboCitiesEl.value }));

function refreshOboUI() {
  chrome.storage.local.get(['obo_status', 'obo_log', 'obo_emails'], (data) => {
    const status = data.obo_status || 'idle';
    const emails = data.obo_emails || [];
    const log = data.obo_log || [];
    document.getElementById('oboStatus').innerHTML = `Status: ${status} | Emails collected: <span class="count">${emails.length}</span>`;
    document.getElementById('oboLog').textContent = log.slice(-100).join('\n');
    document.getElementById('oboEmailCount').textContent = emails.length;
  });
}

document.getElementById('oboStartBtn').addEventListener('click', () => {
  const trades = oboTradesEl.value.split('\n').map(s => s.trim()).filter(Boolean);
  const cities = oboCitiesEl.value.split('\n').map(s => s.trim()).filter(Boolean);
  if (trades.length === 0 || cities.length === 0) {
    alert('Kam az kam aik trade aur aik city likhein.');
    return;
  }
  chrome.storage.local.set({ obo_status: 'running', obo_log: [], obo_emails: [] }, () => {
    chrome.runtime.sendMessage({ action: 'OBO_START', trades, cities });
  });
});
document.getElementById('oboStopBtn').addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'OBO_STOP' });
});
document.getElementById('oboResumeBtn').addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'OBO_RESUME' });
});
document.getElementById('oboSkipBtn').addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'OBO_SKIP' });
});
document.getElementById('oboExportBtn').addEventListener('click', () => {
  chrome.storage.local.get(['obo_emails'], (data) => {
    const emails = data.obo_emails || [];
    if (emails.length === 0) { alert('Abhi koi email collect nahi hui.'); return; }
    exportEmailsTxt(emails, 'obo_emails.txt', 'One-by-One Email Finder');
  });
});

// ============================================================
// PDF TAB
// ============================================================
const pdfTradesEl = document.getElementById('pdfTrades');
const pdfCitiesEl = document.getElementById('pdfCities');
const pdfEmailDomainEl = document.getElementById('pdfEmailDomain');

function restorePdfInputs() {
  chrome.storage.local.get(['pdf_tradesText', 'pdf_citiesText', 'pdf_emailDomainText'], (data) => {
    if (typeof data.pdf_tradesText === 'string') pdfTradesEl.value = data.pdf_tradesText;
    if (typeof data.pdf_citiesText === 'string') pdfCitiesEl.value = data.pdf_citiesText;
    if (typeof data.pdf_emailDomainText === 'string') pdfEmailDomainEl.value = data.pdf_emailDomainText;
  });
}
pdfTradesEl.addEventListener('input', () => chrome.storage.local.set({ pdf_tradesText: pdfTradesEl.value }));
pdfCitiesEl.addEventListener('input', () => chrome.storage.local.set({ pdf_citiesText: pdfCitiesEl.value }));
pdfEmailDomainEl.addEventListener('input', () => chrome.storage.local.set({ pdf_emailDomainText: pdfEmailDomainEl.value }));

function refreshPdfUI() {
  chrome.storage.local.get(['pdf_status', 'pdf_log', 'pdf_emails'], (data) => {
    const status = data.pdf_status || 'idle';
    const emails = data.pdf_emails || [];
    const log = data.pdf_log || [];
    document.getElementById('pdfStatus').innerHTML = `Status: ${status} | Emails collected: <span class="count">${emails.length}</span>`;
    document.getElementById('pdfLog').textContent = log.slice(-100).join('\n');
    document.getElementById('pdfEmailCount').textContent = emails.length;
  });
}

document.getElementById('pdfStartBtn').addEventListener('click', () => {
  const trades = pdfTradesEl.value.split('\n').map(s => s.trim()).filter(Boolean);
  const cities = pdfCitiesEl.value.split('\n').map(s => s.trim()).filter(Boolean);
  const emailDomain = pdfEmailDomainEl.value.trim();
  if (trades.length === 0 || cities.length === 0) {
    alert('Kam az kam aik trade aur aik city likhein.');
    return;
  }
  chrome.storage.local.set({ pdf_status: 'running', pdf_log: [], pdf_emails: [] }, () => {
    chrome.runtime.sendMessage({ action: 'PDF_START', trades, cities, emailDomain });
  });
});
document.getElementById('pdfStopBtn').addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'PDF_STOP' });
});
document.getElementById('pdfExportBtn').addEventListener('click', () => {
  chrome.storage.local.get(['pdf_emails'], (data) => {
    const emails = data.pdf_emails || [];
    if (emails.length === 0) { alert('Abhi koi email collect nahi hui.'); return; }
    exportEmailsTxt(emails, 'pdf_emails.txt', 'PDF Email Finder');
  });
});

// ============================================================
// SHARED EXPORT HELPER (sirf emails, url nahi)
// ============================================================
function exportEmailsTxt(emails, filename, title) {
  const grouped = {};
  const globalSeen = new Set();
  emails.forEach(e => {
    const email = (e.email || '').trim().toLowerCase();
    if (!email || globalSeen.has(email)) return;
    globalSeen.add(email);
    grouped[e.keyword] = grouped[e.keyword] || [];
    grouped[e.keyword].push(email);
  });

  let text = `${title} - Emails Only\nGenerated: ${new Date().toLocaleString()}\nTotal unique emails: ${globalSeen.size}\n\n`;
  for (const keyword in grouped) {
    const unique = [...new Set(grouped[keyword])];
    text += `=== ${keyword} (${unique.length}) ===\n`;
    text += unique.join('\n');
    text += '\n\n';
  }

  const blob = new Blob([text], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  chrome.downloads.download({ url, filename, saveAs: true });
}

// ============================================================
// ADMIN PANEL
// ============================================================
let adminSecret = null;

async function restoreAdminSession() {
  const data = await chrome.storage.session.get(['adminSecret']);
  if (data.adminSecret) {
    adminSecret = data.adminSecret;
    document.getElementById('adminLoginBox').style.display = 'none';
    document.getElementById('adminPanelBox').style.display = 'block';
    loadUsers();
  }
}

document.getElementById('adminLoginBtn').addEventListener('click', async () => {
  const email = document.getElementById('adminEmailInput').value.trim();
  const password = document.getElementById('adminPasswordInput').value;
  if (!email || !password) return;
  const msg = document.getElementById('adminLoginMsg');
  msg.textContent = 'Check kar raha hoon...';
  try {
    const res = await fetch(`${LICENSE_SERVER_URL}/api/admin/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const json = await res.json();
    if (!json.ok) {
      msg.textContent = json.error || 'Email ya password ghalat hai.';
      return;
    }
    adminSecret = json.token;
    await chrome.storage.session.set({ adminSecret: json.token });
    document.getElementById('adminLoginBox').style.display = 'none';
    document.getElementById('adminPanelBox').style.display = 'block';
    loadUsers();
  } catch (e) {
    msg.textContent = 'Server se connect nahi ho pa raha (server deploy hua hai? config.js check karein).';
  }
});

document.getElementById('adminLockBtn').addEventListener('click', async () => {
  adminSecret = null;
  await chrome.storage.session.remove('adminSecret');
  document.getElementById('adminPanelBox').style.display = 'none';
  document.getElementById('adminLoginBox').style.display = 'block';
  document.getElementById('adminPasswordInput').value = '';
});

document.getElementById('generateKeyBtn').addEventListener('click', async () => {
  const label = document.getElementById('newKeyLabel').value.trim();
  try {
    const res = await fetch(`${LICENSE_SERVER_URL}/api/admin/keys`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${adminSecret}` },
      body: JSON.stringify({ label })
    });
    const json = await res.json();
    if (json.ok) {
      document.getElementById('newKeyResult').value = json.key.key;
      document.getElementById('newKeyResultRow').style.display = 'flex';
      loadUsers();
    }
  } catch (e) {
    alert('Key generate nahi ho saki: ' + e.message);
  }
});

document.getElementById('copyKeyBtn').addEventListener('click', () => {
  const input = document.getElementById('newKeyResult');
  input.select();
  document.execCommand('copy');
});

document.getElementById('refreshUsersBtn').addEventListener('click', loadUsers);

async function loadUsers() {
  try {
    const res = await fetch(`${LICENSE_SERVER_URL}/api/admin/keys`, {
      headers: { Authorization: `Bearer ${adminSecret}` }
    });
    const json = await res.json();
    if (!json.ok) return;
    document.getElementById('totalUsersCount').textContent = json.totalUsers;
    const tbody = document.getElementById('usersTableBody');
    tbody.innerHTML = '';
    json.keys.forEach(k => {
      const tr = document.createElement('tr');
      const badgeClass = k.status === 'active' ? 'badge-active' : 'badge-revoked';
      tr.innerHTML = `
        <td>${k.label || '-'}</td>
        <td style="font-size:10px;">${k.key}</td>
        <td><span class="badge ${badgeClass}">${k.status}</span></td>
        <td></td>
      `;
      const actionTd = tr.querySelector('td:last-child');
      const btn = document.createElement('button');
      btn.textContent = k.status === 'active' ? 'Remove' : 'Reactivate';
      btn.style.width = 'auto';
      btn.style.margin = '0';
      btn.style.padding = '4px 8px';
      btn.style.fontSize = '10px';
      btn.className = k.status === 'active' ? 'btn-red' : 'btn-green';
      btn.addEventListener('click', () => toggleKey(k.key, k.status));
      actionTd.appendChild(btn);
      tbody.appendChild(tr);
    });
  } catch (e) {
    // server na mile to silently skip
  }
}

async function toggleKey(key, currentStatus) {
  const endpoint = currentStatus === 'active' ? 'revoke' : 'activate';
  if (currentStatus === 'active' && !confirm('Ye user ka access hata dena hai? Uska extension turant kaam karna band ho jayega.')) return;
  try {
    await fetch(`${LICENSE_SERVER_URL}/api/admin/keys/${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${adminSecret}` },
      body: JSON.stringify({ key })
    });
    loadUsers();
  } catch (e) {
    alert('Update fail: ' + e.message);
  }
}

// ============================================================
// INIT
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
  restoreOboInputs();
  restorePdfInputs();
  refreshDashboard();
  refreshOboUI();
  refreshPdfUI();
  checkLicenseAndGate();
  restoreAdminSession();
});
chrome.storage.onChanged.addListener(() => {
  refreshDashboard();
  refreshOboUI();
  refreshPdfUI();
});
