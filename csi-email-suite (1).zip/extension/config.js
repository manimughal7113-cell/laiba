// ============================================================
// ZAROORI: Server deploy karne ke baad, is line mein apna server
// ka URL daal dein (server/README.md mein deploy karne ka tareeqa hai).
// ============================================================
const LICENSE_SERVER_URL = 'https://REPLACE-WITH-YOUR-SERVER-URL.com';

// Extension/brand ka naam - yahan se change kar sakte hain
const BRAND_NAME = 'CSI Estimation';
