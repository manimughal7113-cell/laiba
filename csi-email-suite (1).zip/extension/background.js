importScripts('config.js');

// ============================================================
// LICENSE CHECKING
// Extension tab tak koi bhi collection START nahi hogi jab tak
// server se "valid" response na mile. Har 10 min mein dobara check
// hota hai, aur har Start dabate waqt bhi check hota hai - taake
// agar admin ne key revoke kar di ho, extension khud lock ho jaye.
// ============================================================

async function validateLicenseKey(key) {
  if (!key) return false;
  try {
    const res = await fetch(`${LICENSE_SERVER_URL}/api/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key })
    });
    const json = await res.json();
    return !!json.valid;
  } catch (e) {
    // Server tak na pahunch sakein (internet issue waghera) to purani
    // license state pe rely karte hain, taake sirf net issue se sab band na ho jaye.
    const data = await chrome.storage.local.get(['licensed']);
    return !!data.licensed;
  }
}

async function ensureLicensed() {
  const data = await chrome.storage.local.get(['licenseKey']);
  const ok = await validateLicenseKey(data.licenseKey);
  await chrome.storage.local.set({ licensed: ok });
  return ok;
}

const LICENSE_CHECK_ALARM = 'license_check_alarm';
chrome.alarms.create(LICENSE_CHECK_ALARM, { periodInMinutes: 10 });
ensureLicensed(); // service worker start hote hi ek dafa check

// ============================================================
// SHARED HELPERS (dono tools istemal karte hain)
// ============================================================

async function appendLog(mode, line) {
  const key = mode + '_log';
  const data = await chrome.storage.local.get([key]);
  const log = data[key] || [];
  log.push(line);
  await chrome.storage.local.set({ [key]: log });
}

async function saveEmails(mode, keyword, url, emails) {
  if (!emails || emails.length === 0) return;
  const key = mode + '_emails';
  const data = await chrome.storage.local.get([key]);
  const existing = data[key] || [];
  const seen = new Set(existing.map(e => e.keyword + '|' + e.email.toLowerCase()));
  let added = 0;
  for (const email of emails) {
    const k = keyword + '|' + email.toLowerCase();
    if (!seen.has(k)) {
      existing.push({ keyword, email, url });
      seen.add(k);
      added++;
    }
  }
  if (added > 0) await chrome.storage.local.set({ [key]: existing });
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function waitForTabComplete(tabId, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error('Tab load timeout'));
    }, timeoutMs);

    function listener(updatedTabId, info) {
      if (updatedTabId === tabId && info.status === 'complete') {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function openTabAndWait(url, timeoutMs = 15000, { skipOnTimeout = false, targetSite = false, onTargetTab } = {}) {
  const tab = await chrome.tabs.create({ url, active: false });
  if (targetSite && onTargetTab) onTargetTab(tab.id);
  try {
    await waitForTabComplete(tab.id, timeoutMs);
  } catch (e) {
    if (skipOnTimeout) {
      try { await chrome.tabs.remove(tab.id); } catch (_) {}
      if (targetSite && onTargetTab) onTargetTab(null);
      throw new Error(`Site load timeout (${Math.round(timeoutMs / 60000)} min) - skipped`);
    }
  }
  await sleep(800);
  return tab;
}

// Injected into Google search results pages (dono tools yehi use karte hain)
function extractGoogleLinksFunc() {
  const anchors = Array.from(document.querySelectorAll('a'));
  const links = anchors
    .map(a => a.href)
    .filter(href =>
      href &&
      href.startsWith('http') &&
      !href.includes('google.com') &&
      !href.includes('googleusercontent.com') &&
      !href.includes('gstatic.com')
    );
  const nextEl = document.querySelector('a#pnnext');
  const nextLink = nextEl ? nextEl.href : null;
  return { links: [...new Set(links)], nextLink };
}

// ============================================================
// ONE-BY-ONE COLLECTION (original logic, sirf naming namespaced)
// ============================================================

let oboStopRequested = false;
let oboSkipCurrentRequested = false;
let oboActiveTargetTabId = null;
const OBO_DEFAULT_PROGRESS = { keywordIndex: 0, page: 0, pageUrl: null, linkIndex: 0, keywords: [] };
const OBO_SAFETY_MAX_PAGES_PER_KEYWORD = 50;

const KEEP_ALIVE_ALARM = 'trade_email_finder_keep_alive';
function startKeepAlive() {
  chrome.alarms.create(KEEP_ALIVE_ALARM, { periodInMinutes: 0.4 });
}
function stopKeepAlive() {
  chrome.alarms.clear(KEEP_ALIVE_ALARM);
}

function extractContactDataFunc() {
  const bodyText = document.body ? document.body.innerText : '';
  const regex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
  const textMatches = bodyText.match(regex) || [];
  const mailtoLinks = Array.from(document.querySelectorAll('a[href^="mailto:"]'))
    .map(a => a.href.replace(/^mailto:/i, '').split('?')[0].trim());
  const allEmails = new Set([...textMatches, ...mailtoLinks]);
  const junkPatterns = [
    /\.(png|jpg|jpeg|gif|svg|webp|css|js)$/i,
    /example\.com$/i, /sentry\.io$/i, /wixpress\.com$/i, /godaddy\.com$/i
  ];
  const emails = Array.from(allEmails).map(e => e.trim()).filter(e => e && !junkPatterns.some(p => p.test(e)));

  const facebookLinks = Array.from(document.querySelectorAll('a[href]'))
    .map(a => a.href)
    .filter(href => {
      try {
        const u = new URL(href);
        return /(^|\.)facebook\.com$/i.test(u.hostname) || /(^|\.)fb\.com$/i.test(u.hostname);
      } catch (_) { return false; }
    })
    .map(href => {
      try { const u = new URL(href); u.search = ''; u.hash = ''; return u.href; } catch (_) { return href; }
    });
  return { emails: [...new Set(emails)], facebookLinks: [...new Set(facebookLinks)] };
}

function extractFacebookEmailsFunc() {
  const bodyText = document.body ? document.body.innerText : '';
  const regex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
  const textMatches = bodyText.match(regex) || [];
  const mailtoLinks = Array.from(document.querySelectorAll('a[href^="mailto:"]'))
    .map(a => a.href.replace(/^mailto:/i, '').split('?')[0].trim());
  const all = new Set([...textMatches, ...mailtoLinks]);
  const junkPatterns = [
    /\.(png|jpg|jpeg|gif|svg|webp|css|js)$/i,
    /example\.com$/i, /sentry\.io$/i, /wixpress\.com$/i, /godaddy\.com$/i
  ];
  return Array.from(all).map(e => e.trim()).filter(e => e && !junkPatterns.some(p => p.test(e)));
}

async function saveOboProgress(p) {
  await chrome.storage.local.set({ obo_resumeProgress: p, obo_savedKeywords: p.keywords || [] });
}
async function clearOboProgress() {
  await chrome.storage.local.remove(['obo_resumeProgress', 'obo_savedKeywords']);
}

async function resumeOboSavedRun() {
  const d = await chrome.storage.local.get(['obo_resumeProgress', 'obo_savedKeywords']);
  const p = d.obo_resumeProgress;
  const keywords = d.obo_savedKeywords || (p && p.keywords) || [];
  if (!p || !keywords.length) {
    await appendLog('obo', '⚠️ Saved progress nahi mili.');
    await chrome.storage.local.set({ obo_status: 'idle' });
    return;
  }
  await runOboSearchFromProgress(keywords, p);
}

async function runOboSearch(trades, cities) {
  const keywords = [];
  for (const trade of trades) {
    for (const city of cities) keywords.push(`${trade} in ${city}`);
  }
  const p = { ...OBO_DEFAULT_PROGRESS, keywords, keywordIndex: 0, page: 0, pageUrl: null, linkIndex: 0 };
  await saveOboProgress(p);
  await runOboSearchFromProgress(keywords, p);
}

async function runOboSearchFromProgress(keywords, progress) {
  for (let keywordIndex = progress.keywordIndex || 0;
       keywordIndex < keywords.length && !oboStopRequested;
       keywordIndex++) {

    const keyword = keywords[keywordIndex];
    await appendLog('obo', `\n🔍 Searching: ${keyword}`);

    let pageUrl = (keywordIndex === progress.keywordIndex && progress.pageUrl)
      ? progress.pageUrl
      : `https://www.google.com/search?q=${encodeURIComponent(keyword)}&num=20`;
    let page = (keywordIndex === progress.keywordIndex && progress.page) ? progress.page : 0;
    let startIndex = (keywordIndex === progress.keywordIndex && progress.linkIndex) ? progress.linkIndex : 0;

    while (pageUrl && page < OBO_SAFETY_MAX_PAGES_PER_KEYWORD && !oboStopRequested) {
      let pageLinks = [], nextLink = null;

      try {
        const tab = await openTabAndWait(pageUrl, 15000);
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id }, func: extractGoogleLinksFunc
        });
        ({ links: pageLinks, nextLink } = results[0].result);
        await chrome.tabs.remove(tab.id);
      } catch (e) {
        await appendLog('obo', `⚠️ Search page error: ${e.message}`);
        await saveOboProgress({ ...progress, keywordIndex, page, pageUrl, linkIndex: startIndex, keywords });
        break;
      }

      page++;
      await appendLog('obo', `  📄 Page ${page}: ${pageLinks.length} sites mile`);

      for (let i = startIndex; i < pageLinks.length; i++) {
        if (oboStopRequested) {
          await saveOboProgress({ ...progress, keywordIndex, page, pageUrl, linkIndex: i, keywords });
          break;
        }

        const link = pageLinks[i];
        await saveOboProgress({ ...progress, keywordIndex, page, pageUrl, linkIndex: i, keywords });

        try {
          await appendLog('obo', `  ↳ Visiting: ${link}`);
          const tab = await openTabAndWait(link, 180000, {
            skipOnTimeout: true,
            targetSite: true,
            onTargetTab: (id) => { oboActiveTargetTabId = id; }
          });

          const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id }, func: extractContactDataFunc
          });
          const contactData = results[0].result || { emails: [], facebookLinks: [] };
          await chrome.tabs.remove(tab.id);
          oboActiveTargetTabId = null;

          if (contactData.emails.length > 0) {
            await saveEmails('obo', keyword, link, contactData.emails);
            await appendLog('obo', `     ✅ ${contactData.emails.length} email(s) website se mile`);
          } else if (contactData.facebookLinks.length > 0) {
            let facebookEmails = [];
            for (const fbLink of contactData.facebookLinks.slice(0, 3)) {
              if (oboStopRequested) break;
              try {
                await appendLog('obo', `     ↳ Website par email nahi mila; Facebook check: ${fbLink}`);
                const fbTab = await openTabAndWait(fbLink, 180000, {
                  skipOnTimeout: true,
                  targetSite: true,
                  onTargetTab: (id) => { oboActiveTargetTabId = id; }
                });
                const fbResults = await chrome.scripting.executeScript({
                  target: { tabId: fbTab.id }, func: extractFacebookEmailsFunc
                });
                facebookEmails = fbResults[0].result || [];
                await chrome.tabs.remove(fbTab.id);
                oboActiveTargetTabId = null;
                if (facebookEmails.length > 0) {
                  await saveEmails('obo', keyword, link, facebookEmails);
                  await appendLog('obo', `     ✅ ${facebookEmails.length} email(s) Facebook se mile`);
                  break;
                }
              } catch (fbError) {
                oboActiveTargetTabId = null;
                await appendLog('obo', `     ⚠️ Facebook skip (${fbError.message})`);
              }
            }
            if (!facebookEmails.length)
              await appendLog('obo', `     ➜ Website/Facebook dono par email nahi mila; next website.`);
          } else {
            await appendLog('obo', `     ➜ Website par email nahi mila aur Facebook link nahi mila; next website.`);
          }
        } catch (e) {
          oboActiveTargetTabId = null;
          await appendLog('obo', `     ⚠️ Skip (${e.message})`);
        }

        await saveOboProgress({ ...progress, keywordIndex, page, pageUrl, linkIndex: i + 1, keywords });
        await sleep(800 + Math.random() * 800);
      }

      if (oboStopRequested) break;
      pageUrl = nextLink;
      startIndex = 0;
      if (pageUrl) {
        await saveOboProgress({ ...progress, keywordIndex, page, pageUrl, linkIndex: 0, keywords });
        await sleep(1500 + Math.random() * 1500);
      }
    }

    if (oboStopRequested) break;

    await appendLog('obo', `  ✔ Keyword mukammal: "${keyword}" (${page} page(s) process hue)`);
    progress = { ...progress, keywordIndex: keywordIndex + 1, page: 0, pageUrl: null, linkIndex: 0, keywords };
    await saveOboProgress(progress);
  }

  stopKeepAlive();

  if (oboStopRequested) {
    await chrome.storage.local.set({ obo_status: 'stopped' });
    await appendLog('obo', '\n⏹ Rok diya gaya. Progress save hai — Resume se wahi se continue hoga.');
  } else {
    await chrome.storage.local.set({ obo_status: 'done' });
    await clearOboProgress();
    await appendLog('obo', '\n✅ Sab keywords mukammal ho gaye!');
  }
}

// ============================================================
// PDF COLLECTION (original logic, sirf naming namespaced)
// ============================================================

let pdfStopRequested = false;
const PDF_SAFETY_MAX_PAGES_PER_KEYWORD = 50;

let offscreenReady = null;
async function ensureOffscreenDocument() {
  if (offscreenReady) return offscreenReady;
  offscreenReady = (async () => {
    const existing = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    if (existing && existing.length > 0) return;
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['DOM_PARSER'],
      justification: 'PDF files ke andar se text nikaalne ke liye pdf.js library chalani hai, jisay DOM chahiye.'
    });
  })();
  return offscreenReady;
}

async function processPdf(url) {
  await ensureOffscreenDocument();
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { target: 'offscreen', action: 'processPdf', url },
      (response) => {
        if (chrome.runtime.lastError) {
          resolve({ ok: false, error: chrome.runtime.lastError.message });
          return;
        }
        resolve(response || { ok: false, error: 'No response' });
      }
    );
  });
}

function sanitizeFilename(name) {
  return name.replace(/[^a-z0-9_\-]+/gi, '_').slice(0, 80);
}

let downloadCounter = 0;
async function downloadImagePdf(pdfUrl, keyword) {
  downloadCounter++;
  const namePart = sanitizeFilename(keyword) || 'pdf';
  const filename = `PDF_Email_Finder/${namePart}_${downloadCounter}.pdf`;
  try {
    await chrome.downloads.download({ url: pdfUrl, filename, saveAs: false });
    return true;
  } catch (e) {
    await appendLog('pdf', `     ⚠️ Download fail: ${e.message}`);
    return false;
  }
}

async function runPdfSearch(trades, cities, emailDomain) {
  const keywords = [];
  for (const trade of trades) {
    for (const city of cities) keywords.push(`${trade} in ${city}`);
  }

  const domainFilter = emailDomain ? ` "@${emailDomain}"` : '';

  for (const keyword of keywords) {
    if (pdfStopRequested) break;

    const searchQuery = `${keyword}${domainFilter} filetype:pdf`;
    await appendLog('pdf', `\n🔍 Searching: ${searchQuery}`);

    let pageUrl = `https://www.google.com/search?q=${encodeURIComponent(searchQuery)}&num=20`;
    let page = 0;
    const seenLinksThisKeyword = new Set();

    while (pageUrl && page < PDF_SAFETY_MAX_PAGES_PER_KEYWORD && !pdfStopRequested) {
      let pageLinks = [];
      let nextLink = null;
      try {
        const tab = await openTabAndWait(pageUrl, 15000);
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: extractGoogleLinksFunc
        });
        ({ links: pageLinks, nextLink } = results[0].result);
        await chrome.tabs.remove(tab.id);
      } catch (e) {
        await appendLog('pdf', `⚠️ Search page error: ${e.message}`);
        break;
      }

      page++;
      const pdfLinks = pageLinks.filter(l => l.toLowerCase().includes('.pdf'));
      await appendLog('pdf', `  📄 Page ${page}: ${pdfLinks.length} PDF link(s) mile`);

      for (const link of pdfLinks) {
        if (pdfStopRequested) break;
        if (seenLinksThisKeyword.has(link)) continue;
        seenLinksThisKeyword.add(link);

        await appendLog('pdf', `  ↳ PDF check kar raha hoon: ${link}`);
        try {
          const result = await processPdf(link);

          if (!result.ok) {
            await appendLog('pdf', `     ⚠️ Skip (${result.error})`);
          } else if (result.emails.length > 0) {
            await saveEmails('pdf', keyword, link, result.emails);
            await appendLog('pdf', `     ✅ ${result.emails.length} email(s) mile`);
          } else if (result.isImageBased) {
            await appendLog('pdf', `     🖼️ Image-based PDF lag raha hai, download kar raha hoon...`);
            const downloaded = await downloadImagePdf(link, keyword);
            if (downloaded) {
              await appendLog('pdf', `     ⬇️ Download ho gaya (Downloads/PDF_Email_Finder folder mein).`);
            }
          } else {
            await appendLog('pdf', `     ⚠️ Text mila lekin koi email nahi, agle pe ja raha hoon.`);
          }
        } catch (e) {
          await appendLog('pdf', `     ⚠️ Skip (${e.message})`);
        }

        await sleep(600 + Math.random() * 600);
      }

      pageUrl = nextLink;
      if (pageUrl) {
        await sleep(1500 + Math.random() * 1500);
      }
    }

    await appendLog('pdf', `  ✔ Keyword mukammal: "${keyword}" (${page} page(s) process hue)`);
  }

  await chrome.storage.local.set({ pdf_status: pdfStopRequested ? 'stopped' : 'done' });
  await appendLog('pdf', pdfStopRequested ? '\n⏹ Rok diya gaya.' : '\n✅ Sab keywords mukammal ho gaye!');
}

// ============================================================
// MESSAGE ROUTING
// ============================================================

chrome.runtime.onMessage.addListener((msg) => {
  switch (msg.action) {
    case 'OBO_START':
      (async () => {
        const ok = await ensureLicensed();
        if (!ok) { await appendLog('obo', '🚫 License invalid/revoked hai. Admin se naya key lein.'); return; }
        oboStopRequested = false;
        oboSkipCurrentRequested = false;
        startKeepAlive();
        runOboSearch(msg.trades, msg.cities);
      })();
      break;

    case 'OBO_STOP':
      oboStopRequested = true;
      appendLog('obo', 'Stop request bheja gaya... progress save hogi.');
      break;

    case 'OBO_SKIP':
      oboSkipCurrentRequested = true;
      appendLog('obo', '⏭ Current website skip request bheji gayi.');
      if (oboActiveTargetTabId !== null) {
        chrome.tabs.remove(oboActiveTargetTabId).catch(() => {});
      }
      break;

    case 'OBO_RESUME':
      (async () => {
        const ok = await ensureLicensed();
        if (!ok) { await appendLog('obo', '🚫 License invalid/revoked hai. Admin se naya key lein.'); return; }
        oboStopRequested = false;
        oboSkipCurrentRequested = false;
        startKeepAlive();
        resumeOboSavedRun();
      })();
      break;

    case 'PDF_START':
      (async () => {
        const ok = await ensureLicensed();
        if (!ok) { await appendLog('pdf', '🚫 License invalid/revoked hai. Admin se naya key lein.'); return; }
        pdfStopRequested = false;
        runPdfSearch(msg.trades, msg.cities, msg.emailDomain);
      })();
      break;

    case 'PDF_STOP':
      pdfStopRequested = true;
      appendLog('pdf', 'Stop request bheja gaya... current step khatam hote hi ruk jayega.');
      break;

    case 'CHECK_LICENSE':
      ensureLicensed();
      break;
  }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === LICENSE_CHECK_ALARM) {
    ensureLicensed();
  }
  // KEEP_ALIVE_ALARM ka koi listener code nahi chahiye - sirf wake hona kaafi hai
});
