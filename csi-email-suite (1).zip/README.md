# CSI Estimation - Email Collection Suite (Extension + License Server)

Ye package do hisson mein hai:

- **`extension/`** — Chrome extension (Dashboard + One-by-One + PDF Finder + Admin, sab ek jagah)
- **`server/`** — License server (keys generate/revoke/validate karne ke liye)

## Setup Order (Zaroori — Isi Tarteeb Mein Karein)

### 1. Pehle Server Deploy Karein
`server/README.md` mein poora tareeqa hai (Render.com free tier recommended).
Deploy hone ke baad aapko ek URL milega, jaise:
`https://csi-license-server.onrender.com`

### 2. Extension Mein Server URL Daalein
`extension/config.js` file kholein aur ye line update karein:
```js
const LICENSE_SERVER_URL = 'https://csi-license-server.onrender.com';
```

### 3. Extension Load Karein
1. `chrome://extensions` > Developer mode ON
2. "Load unpacked" > `extension` folder select karein

### 4. Admin Ke Taur Par Login Karein
1. Extension icon > **Admin** tab
2. Wahi password daalein jo aapne server deploy karte waqt `ADMIN_SECRET` mein set kiya tha
3. Ab aap:
   - **Generate Key** — naya license key banayein (kisi user ko dene ke liye)
   - **Users table** — dekhein kitne active users hain, aur kisi ka bhi access **Remove** button se hata sakte hain

### 5. User Ko Extension Dena
- User ko sirf `extension` folder de dein (ya zip)
- User load karega, extension **License Key** maangega
- Aap generate ki hui key usay bhej dein — wo daal kar Activate karega
- Jab tak key active hai, dono tools (One-by-One + PDF Finder) kaam karenge
- Jaise hi aap us key ko Admin panel se **Remove** karenge, us user ka extension **10 minute ke andar khud lock ho jayega** (background mein har 10 min baad check hota hai, aur har baar jab wo Start dabaye tab bhi check hota hai)

## Kya Tabdeel Hua, Kya Nahi

**Nahi badla (jaisa tha waisa hi hai):**
- One-by-One collection ka poora logic (Google search, Facebook fallback, resume/skip) — bilkul same
- PDF Finder ka poora logic (PDF text extraction, image-based PDF download) — bilkul same

**Naya kya hai:**
- Dono tools ek hi extension mein, tabs ke zariye
- Dashboard tab — combined stats, aur "Clear All Data" button (data khud kabhi delete nahi hota)
- License-key gate — bina valid key extension kaam nahi karega
- Admin tab — key generate/remove, aur total active users ka record
- Har tool ka data alag rakha gaya hai (storage keys namespaced) taake mix na ho

## Files
```
extension/
  manifest.json, background.js, popup.html, popup.js, config.js
  offscreen.html, offscreen.js, pdf.min.js, pdf.worker.min.js
  icon.png
server/
  server.js, package.json, README.md
```
